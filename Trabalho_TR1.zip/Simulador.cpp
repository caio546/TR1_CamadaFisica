#include <iostream>
#include <vector>
#include <ncurses.h>
#include <unistd.h>
#include <chrono>
#include <thread>
#include "CamadaFisica.hpp"
 
int main() {

  AplicacaoTransmissora();
    
  return 0;
}